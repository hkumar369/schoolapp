from django.shortcuts import render

# Create your views here.
def feeCollection(request):
    return render(request, 'finance/feesCollection.html');

def feeDueReport(request):
    return render(request, 'finance/feesDue.html');

def feeCollectionReport(request):
    return render(request, 'finance/feesCollectionReport.html');
