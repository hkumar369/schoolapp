from django.urls import path
from Finance.views import feeCollection
from Finance.views import feeDueReport
from Finance.views import feeCollectionReport
urlpatterns = [


    path('feesCol/', feeCollection),
    path('due/', feeDueReport),
    path('feeR/', feeCollectionReport),

]
