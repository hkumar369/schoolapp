from django.shortcuts import render
from admissions.models import Student
from admissions.form import studentform


# Create your views here.
def homepage(request):
    return render(request, 'index.html');


def addadmissions(request):
    form = studentform
    addstudent = {'form':form}

    if request.method=="POST":
        form =studentform(request.POST)
        if form.is_valid():
            form.save()
        return homepage(request)


  #  values = {"name": "Hemanth", "phn": 9948251445, "city": "Kurnool"}
    return render(request, 'admission/addAdmissions.html', addstudent);



def admissionReport(request):
    result = Student.objects.all()
    dicti = {'allstudents':result}
    return render(request, 'admission/admissionReport.html', dicti);
