from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=30)
    fatherName = models.CharField(max_length=30)
    className = models.IntegerField()
    Phone = models.CharField(max_length=12)