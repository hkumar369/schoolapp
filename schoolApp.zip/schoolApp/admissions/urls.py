from django.urls import path
from admissions.views import addadmissions
from admissions.views import admissionReport

urlpatterns = [

    path('newadm/', addadmissions),
    path('admrep/', admissionReport),


]
