from django import forms
from admissions.models import Student


class studentform(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'
